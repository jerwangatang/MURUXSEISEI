// --------------------------------------------------
// MAIN MENU - CREATE EVENT
// --------------------------------------------------

// Current menu page
menu_page = "main";

// Current selected option
menu_selected = 0;


// --------------------------------------------------
// MAIN MENU ITEMS
// --------------------------------------------------

main_items = [
    "play",
    "settings",
    "help",
    "credits",
    "quit"
];


// --------------------------------------------------
// SETTINGS ITEMS
// --------------------------------------------------

settings_items = [
    "music volume",
    "sfx volume",
    "fullscreen",
    "back"
];


// --------------------------------------------------
// SETTINGS VALUES
// --------------------------------------------------

music_volume = 100;
sfx_volume = 100;
audio_sound_gain(snd_menu_move, sfx_volume / 100, 0);
audio_sound_gain(snd_menu_select, sfx_volume / 100, 0);


// --------------------------------------------------
// POSITION
// --------------------------------------------------

menu_x = display_get_gui_width() / 2;
menu_y = 500;

menu_spacing = 50;

menu_width = 300;
menu_height = 40;


// --------------------------------------------------
// SAVE
// --------------------------------------------------

has_save = false;


// --------------------------------------------------
// QUIT CONFIRMATION
// --------------------------------------------------

quit_selected = 1;
// 0 = yes
// 1 = no

// ==================================================
// SAVE SLOT MENU
// ==================================================

save_selected = 0;

save_info = [
    scr_get_save_info(1),
    scr_get_save_info(2),
    scr_get_save_info(3)
];


refresh_save_slots = function()
{
    save_info[0] =
        scr_get_save_info(1);

    save_info[1] =
        scr_get_save_info(2);

    save_info[2] =
        scr_get_save_info(3);
};